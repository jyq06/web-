package me.lancer.cms.model;

public interface ConstValue {
	public int CONST_ROOT = 0;
	public int CONST_PLAYTYPE = 1;
	public int CONST_PLAYLANG = 2;
	public int CONST_INTERVAL = 3;
}
