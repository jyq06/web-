# Cinema-Management-System-Java
## 简介
大二下期 Java GUI 课程设计——影院管理系统 Java GUI 版.

## 技术
1. Java Swing.
2. MySQL.
3. MVC.

## 截图

<img src="https://github.com/1anc3r/Cinema-Management-System-Java/blob/master/Screenshots/1.png?raw=true" width = "1092" height = "500" alt="1" />
<img src="https://github.com/1anc3r/Cinema-Management-System-Java/blob/master/Screenshots/2.png?raw=true" width = "1092" height = "500" alt="2" />
<img src="https://github.com/1anc3r/Cinema-Management-System-Java/blob/master/Screenshots/3.png?raw=true" width = "1092" height = "500" alt="3" />
<img src="https://github.com/1anc3r/Cinema-Management-System-Java/blob/master/Screenshots/4.png?raw=true" width = "1092" height = "500" alt="4" />
<img src="https://github.com/1anc3r/Cinema-Management-System-Java/blob/master/Screenshots/5.png?raw=true" width = "1092" height = "500" alt="5" />
<img src="https://github.com/1anc3r/Cinema-Management-System-Java/blob/master/Screenshots/6.png?raw=true" width = "1092" height = "500" alt="6" />
<img src="https://github.com/1anc3r/Cinema-Management-System-Java/blob/master/Screenshots/7.png?raw=true" width = "1092" height = "500" alt="7" />
